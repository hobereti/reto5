package model.vo;

public class Consulta2VO_49 {
    private String nombre;
    private int salario ; 
    private double isr;
    private String ape;
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getSalario() {
        return salario;
    }
    public void setSalario(int salario) {
        this.salario = salario;
    }
    public double getIsr() {
        return isr;
    }
    public void setIsr(double isr) {
        this.isr = isr;
    }
    public String getApe() {
        return ape;
    }
    public void setApe(String ape) {
        this.ape = ape;
    }
     
}