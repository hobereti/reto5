package model.vo;

public class Consulta3VO_49 {
    //Atributos
    private String constructora;
    private int banos ;
    private String nombre ;
    
    public String getConstructora() {
        return constructora;
    }
    public void setConstructora(String constructora) {
        this.constructora = constructora;
    }
    public int getBanos() {
        return banos;
    }
    public void setBanos(int banos) {
        this.banos = banos;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    } 


}